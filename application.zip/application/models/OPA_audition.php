<?php

class OPA_audition extends CI_Controller
{
    public function __construct() 
    {
        parent::__construct();
    }
    
    function available_audition()
    {
        $this -> db -> where('name', 'steunzoolauditie');
        $this -> db -> or_where('name', 'artiestenauditie');
        $result = $this -> db -> get('settings');
        
        $audition = array(
          'audition_count' => 0  
        );
        foreach($result -> result() as $row)
        {
            if($row -> active)
            {
                $audition['audition_count']++;
                $audition[$audition['audition_count']]['name'] = $row -> name;
                $audition[$audition['audition_count']]['text'] = $row -> text;
            }
        }
        
        return $audition;       
    }
    
    function get_audition_by_name( $audition_name )
    {
        $this -> db -> where('name', $audition_name);
        $result = $this -> db -> get('settings');
        
        return $result -> row();
    }
}
?>
