<div class='container' id='tbox1'>
    
<?php

echo $text."<br />";
echo form_open("audition/do_audition/$name/send");
?>
Naam:<br /> 
<input type='text' name='name'/><br />
Leerlingnummer:<br /> 
<input type='text' name='number' /><br />
Klas: <br />
<input type='text' name='class'/><br />
ervaringen: <br />
<textarea name='experience' cols='40' rows='5'></textarea><br />
Motivatie: <br />
<textarea name='motivation' cols='40' rows='5'></textarea><br />
<input type='submit' value='verzend' class="button"/>
</form>
</div>

<div class='container' id='sidebar'>
<img src='<?php echo base_url()?>style/images/robot.jpg' width='576' height='384'/>
</div>
