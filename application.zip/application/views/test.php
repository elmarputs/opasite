hoi

<?php
if(isset($test)) echo $test;

echo $contents;

?>
