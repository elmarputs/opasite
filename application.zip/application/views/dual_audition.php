<div class='container' id='tbox1'>
doe auditie voor techneut:   
<?php
    echo anchor("audition/do_audition/steunzoolauditie", 'techneuten', 'class="button"');
?>

</div>
<div class='container' id='tbox2'>
doe auditie voor artiest:
<?php
    echo anchor("audition/do_audition/artiestenauditie", 'artiesten', 'class="button"');
?>

</div>